
//= require dataTables/datatables.min.js
//= require daterangepicker/daterangepicker.js
//= require chosen/chosen.jquery.js
//= require application/history/index.js