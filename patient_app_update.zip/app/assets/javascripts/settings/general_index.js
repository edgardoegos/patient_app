
//= require cropper/cropper.min.js
//= require application/settings/general/index.js