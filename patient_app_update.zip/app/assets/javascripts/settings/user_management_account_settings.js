
//= require application/settings/user_management/account_settings.js