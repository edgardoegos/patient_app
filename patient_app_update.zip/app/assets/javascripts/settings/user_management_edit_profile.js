//= require datapicker/bootstrap-datepicker.js

//= require select2/select2.full.min.js

//= require cropper/cropper.min
//= require application/settings/user_management/edit_profile.js