//= require video/responsible-video.js
//= require sparkline/jquery.sparkline.min.js
//= require jquery-ui/jquery-ui-1.10.4.min.js