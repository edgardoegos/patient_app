module AppviewsHelper
end
