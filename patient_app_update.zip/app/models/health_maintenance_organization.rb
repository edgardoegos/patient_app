class HealthMaintenanceOrganization < ActiveRecord::Base
end
